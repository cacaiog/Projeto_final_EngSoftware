# pwm-food-place
Food Ordering website where customers can place orders

# Team Members:
- Eduarda Gomes
- Gustavo Antunes
- Mariana Zanon
- Victor Macaúbas

# How to make a Pull Request:

[Como criar uma solicitação de pull](https://docs.github.com/pt/pull-requests/collaborating-with-pull-requests/proposing-changes-to-your-work-with-pull-requests/creating-a-pull-request)

# How to create a git branch in vscode:

[Using Git source control in VS Code](https://code.visualstudio.com/docs/sourcecontrol/overview#:~:text=You%20can%20create%20and%20checkout,tags%20in%20the%20current%20repository.)
